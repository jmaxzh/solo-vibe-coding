Solo Vibe Coding / 玻璃折射官网候选预览

这是完整静态网站预览，不是Skill安装包。

1. 解压本ZIP，进入包含solo-vibe-coding文件夹的目录。
2. 在该目录的终端运行：
   python3 -m http.server 8080 --bind 127.0.0.1
3. 在浏览器打开：
   中文：http://127.0.0.1:8080/solo-vibe-coding/zh-CN/
   English：http://127.0.0.1:8080/solo-vibe-coding/

请通过HTTP打开页面，确保脚本、字体和复制功能正常。
可浏览四类任务、切换语言、进入上手页、复制安装命令、查看案例并下载ZIP，或使用报价计算器和CSV下载。安装命令不会在浏览器中执行。

主视觉为装饰示意，使用演示不代表已执行成果。Skill本身MIT许可；编程助手及第三方服务可能另收费。字体与其他组件的许可保留在solo-vibe-coding/licenses中，项目许可见本包LICENSE。

本候选等待用户确认，解压和本地预览不会修改正式网站。
